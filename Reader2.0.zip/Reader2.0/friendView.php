<?php

?>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>MyNotes</title>
		<link href="group.php" type="text/css" rel="stylesheet"/>
	</head>

	<body>
		<div class="bannerDiv">
			<span class="title">MYNotes</span>
			<span><a herf="">社区</a></span>
			<span><a herf="">好友</a></span>
			<span><a herf="">小组</a></span>
		</div>

		<div class="informationDiv">
			<div>
				<img src="Image/userImage.png"/>
			</div>
			<div>
				<span>用户名:Kaze</span></br>
				<span>用户ID:10389223</span></br>
				<span>用户邮箱:apir8181@qq.com</span>
			</div>
		</div>

		<div class="selectDiv">
			<p>好友信息</p>

			<div>
				<div>
					<img src="Image/userImage.png"/>
				</div>
				<div>
					<span>用户名:Yume</span></br>
					<span>用户ID:12345678</span></br>
					<span>用户邮箱:kazenoyumechen@gmail.com</span>
				</div>
			</div>	

			<div>
				<span>标题</span>
				<span>对象</span>
				<span>内容</span>
				<span>创建时间</span>
			</div>

			<div>
				<span>今天记得看LB</span>
				<span>Little Buster</span>
				<span>我要看！！！</span>
				<span>2012.12.1</span>
			</div>
		</div>

	</body>

</html>