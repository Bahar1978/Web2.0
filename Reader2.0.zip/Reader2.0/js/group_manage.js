window.onload = function()
{
	UpdateMember();
}

function UpdateMember()
{
	var request = new Ajax.Request("connection/group_controler.php?flag=memberQuery",
								{
									method:"post",
									parameters:"gid=" + $("inputGid").value,
									onSuccess:UpdateMemberSuccess 
								});
}

function UpdateMemberSuccess(ajax)
{
	var array = eval('('+ ajax.responseText +')');
	alert(array);
}