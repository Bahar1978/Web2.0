<?
session_start();
include ("db_connection.php");

if (isset($_REQUEST['flag']))
{
	$flag = $_REQUEST['flag'];
}
$result;
switch ($flag) {
	case 'make':
		$uid1 = (int)($_POST['uid1']);
		$uid2 = (int)($_POST['uid2']);
		$result = friends_Make($uid1,$uid2);
		break;
	
	case 'query':
		$name = $_POST['targetname'];
		$result = friends_Query($name);
		break;

	case 'get':
		$uid = (int)($_POST['uid']);
		$result = friends_Get($uid);
		break;

	case 'notification':
		$result = friends_Notification();
		$result = json_encode($result);
		print $result;
		return;
		break;

	default:
		break;
}
print_r ($result);


function friends_Make($uid1,$uid2)
{
	$mysql = Database::GetConnection();
	$query = "insert into Friends values($uid1,$uid2)";
	$result = mysql_query($query);
	$query = "insert into Friends values($uid2,$uid1)";
	$result = mysql_query($query);
	$query = "delete from FriendsQuery where uid1=$uid1 and uid2=$uid2";
	$result = mysql_query($query);
	$query = "delete from FriendsQuery where uid1=$uid2 and uid2=$uid1";
	$result = mysql_query($query);
	Database::CloseConnection($mysql);
	return $result; 
}

function friends_Notification()
{
	$uid = (int)($_SESSION['uid']);
	$mysql = Database::GetConnection();
	$query = "select * from FriendsQuery where uid2 = $uid";
	$temp = mysql_query($query);
	$result = array();


	$number = mysql_num_rows($temp);
	for ($i = 0; $i < $number; $i ++)
	{
		$array = mysql_fetch_array($temp);
		$targetId = (int)($array['uid2']);
		$query = "select * from Users where uid=$targetId";
		$temp2 = mysql_query($query);
		$array = mysql_fetch_array($temp2);
		$result[count($result)] = $array['username'];
	}
	

	Database::CloseConnection($mysql);
	return $result;
}

function friends_Query($name)
{
	$uid1 = (int)($_SESSION['uid']);
	$mysql = Database::GetConnection();
	$query = "select * from Users where username='$name'";
	$temp = mysql_query($query);
	if (mysql_num_rows($temp) > 0)
	{
		$array = mysql_fetch_array($temp);
		$uid2 = (int)($array['uid']);

		if ($uid2 == $uid1)
		{
			$result = "不能添加自己为好友";
		}
		else{
			$query = "select * from Friends where uid1=$uid1 and uid2=$uid2";
			$temp = mysql_query($query);
			if (mysql_num_rows($temp) > 0)
			{
				$result = "与用户" . $name . "已为好友";
			}
			else
			{
				$query = "select * from FriendsQuery where uid1=$uid1 and uid2=$uid2";
				$temp = mysql_query($query);
				if (mysql_num_rows($temp) > 0)
				{
					$result = "请求已发送";
				}
				else
				{
					$since = date("Y-m-d H:i:s");
					$query = "insert into FriendsQuery values($uid1,$uid2,'$since')";
					$result = mysql_query($query);
					$result = "请求已发送";
				}
			}
		}
	}
	else
	{
		$result = "用户不存在";
	}

	Database::CloseConnection($mysql);
	return $result;
}

//return friends info
function friends_Get($uid1)
{
	$mysql = Database::GetConnection();
	$query = "select * from Friends where uid1=$uid1";
	$temp = mysql_query($query);
	
	$num = mysql_num_rows($temp);
	$result = array();
	for ($i = 0; $i < $num; $i ++)
	{
		$array = mysql_fetch_array($temp);
		$uid2 = (int)($array['uid2']);
		$query = "select * from Users where uid=$uid2";
		$innerTemp = mysql_query($query);
		$array = mysql_fetch_array($innerTemp);
		$result[count($result)] = $array;
	}

	Database::CloseConnection($mysql);
	return $result;
}


function getMd5($uid)
{
	return md5($uid . "Reader2.0");
}

function checkMd5($sessionId)
{
	return getMd5($_SESSION['uid']) == $sessionId;
}
?>