<html>
	<head>
		<title>Register</title>
	</head>

	<body>
		<form action="user_controler.php?flag=register" method="POST">
			username<input type="text" name="username" /></br>
			password<input type="password" name="password"/></br>
			email<input type="text" name="email"/></br>
			<input type="submit"/>
		</form>
	</body>
</html>