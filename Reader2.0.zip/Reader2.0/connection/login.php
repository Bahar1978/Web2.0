<html>
	<head>
		<title>Login</title>
	</head>

	<body>
		<form action="user_controler.php?flag=login" method="POST">
			username<input type="text" name="username" /></br>
			password<input type="password" name="password"/></br>
			<input type="submit"/>
		</form>
	</body>
</html>