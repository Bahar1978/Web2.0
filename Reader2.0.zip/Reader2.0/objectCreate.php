<?php

?>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>MyNotes</title>
		<link href="group.php" type="text/css" rel="stylesheet"/>
	</head>

	<body>
		<div class="bannerDiv">
			<span class="title">MYNotes</span>
			<span><a herf="">社区</a></span>
			<span><a herf="">好友</a></span>
			<span><a herf="">小组</a></span>
		</div>

		<div class="informationDiv">
			<div>
				<img src="Image/userImage.png"/>
			</div>
			<div>
				<span>用户名:Kaze</span></br>
				<span>用户ID:10389223</span></br>
				<span>用户邮箱:apir8181@qq.com</span>
			</div>
		</div>

		<div class="contentDiv">
			<p>添加对象</p>
			<form action="" method="post">
				名称:<input type="text" name="name"/></br>
				详细信息:</br>
				<textarea cols="50" rows="20" name="description"></textarea></br>
				<input type="submit" value="提交"/>
				<input type="button"  value="返回"/>
			</form>
		</div>

	</body>

</html>