window.onload = function()
{
	$("logout").addEventListener('click',OnLogoutButtonClicked);
	$("addButton").addEventListener('click',OnAddButtonClicked);
	UpdateNotification();
}

function getCookie(name){
	var cookie=document.cookie;
	var array= cookie.split("; ");
	for(var i=0;i<array.length;i++)
	{
		var arr = array[i].split("=");
		if(arr[0]==name)return arr[1];
	}
	return "";
}

function setCookie(name,value,time)
{
	var date = new Date();
	date.setTime(date.getTime() + time);
	document.cookie = name + "=" + value + ";expires=" + date.toGMTString();
}

function deleteCookie(name)
{
	var exp = new Date();
	exp.setTime(exp.getTime() - 1);
	var cval=getCookie(name);
	if(cval!=null) document.cookie= name + "=" + cval + ";expires="+exp.toGMTString();
}

function OnLogoutButtonClicked(event)
{
	var oldDate = new Date();
	oldDate.setTime(oldDate.getTime() - 1);
	deleteCookie("username");
	deleteCookie("email");
	deleteCookie("sessionId");
	window.location.href="login.php";
}

function UpdateNotification()
{
	var request = new Ajax.Request("connection/friends_controler.php?flag=notification",
								{
									method:"post",
									onSuccess:AjaxNotificationSuccess
								});
}

function AjaxNotificationSuccess(ajax)
{
	var array = eval('('+ ajax.responseText +')');

	var child = $("noteDiv").firstChild;
	child = child.nextSibling;
	while (child != null)
	{
		var temp = child;
		child = child.nextSibling;
		temp.removeChild(temp);
	} 

	for (var i = 0; i < array.length; i ++)
	{
		var div = $("noteDiv").createElement("div");
		div.innerHTML= "<p>用户" + array[i] + "添加你为好友</p>" + 
			       		    "<img src='Image/ok.png'/>" + 
					    "<img src='Image/cancel.png/>'";
	}
}


function OnAddButtonClicked(event)
{
	var par = "targetname=" + $("searchContent").value;
	var request = new Ajax.Request("connection/friends_controler.php?flag=query",
								{
									method:"post",
									parameters:par,
									onSuccess:AjaxAddSuccess
								});
}

function AjaxAddSuccess(ajax)
{
	$("warning").innerHTML = ajax.responseText;
}