<html>
	<head>
		<meta charset="utf-8"/>
		<title>MyNotes</title>
		<script src="register.js"></script>
		<script src="prototype.js"/></script>
	</head>

	<body>
		<div class="bannerDiv">
			<span class="title">MYNotes</span>
		</div>

		<div>
			<form>
				用户名: <input type="text"  id="username"/></br>
				密码: <input type="password" id="password"/></br>
				电子邮件: <input type="text" id = "email" /></br>
				<span id="warning"></span></br>
				<input type="button" id="okButton" value="提交"/>
				<input type="button" id="cancelButton" value="取消"/>
			</form>
		</div>
	</body>

</html>